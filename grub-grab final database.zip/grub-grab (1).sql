-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2023 at 03:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grub-grab`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminID` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminID`, `email`, `password`, `first_name`, `last_name`) VALUES
(1, 'alyssa@gmail.com', '151d1bf0c57afa45e7160c1d24aa2c8d', 'Alyssa', 'Trompeta');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_concessioner`
--

CREATE TABLE `tbl_concessioner` (
  `concessionerID` int(10) UNSIGNED NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_concessioner`
--

INSERT INTO `tbl_concessioner` (`concessionerID`, `firstName`, `lastName`, `business_name`, `email`, `password`, `contact_no`) VALUES
(1, 'Jeffrey', 'De los Reyes', 'Tod Kuya', 'todkuya@gmail.com', 'e9a17214467b733e754848f1a6a1c783', '09665554444'),
(2, 'Maria', 'De la Cruz', 'Maria The Hidden Gem', 'toothcandy@gmail.com', '1ca2c9e29f309febc0c076b482815a19', '09444443333'),
(3, 'Michie', 'Cruz', 'Egg Stop', 'eggstop@gmail.com', 'b2693d9c2124f3ca9547b897794ac6a1', '+634445555'),
(4, 'Marie', 'Cruz', 'Candid Store', 'candidshop@gmail.com', 'b3725122c9d3bfef5664619e08e31877', '+634445344'),
(5, 'Llean', 'Sumague', 'Llean Sizzle and Stir', 'llean@gmail.com', '16c7712ee6356d3e4ef8766b50a29ef7', '+634445533'),
(6, 'Menta', 'Jane', 'The Quirky Curry', 'menta@gmail.com', 'b8d4891bbb304bc7e0ab4b317af2508c', '+6344555666'),
(7, 'Michael', 'Diaz', 'Justine Cuisine', 'michael@gmail.com', '0acf4539a14b3aa27deeb4cbdf6e989f', '+634445556666'),
(8, 'Ana', 'Tanglao', 'Ana Candid Store', 'ana@gmail.com', '276b6c4692e78d4799c12ada515bc3e4', '+6344455556666'),
(9, 'Michelle', 'Moronne', 'Michelle Odyssey', 'michelle@gmail.com', '2345f10bb948c5665ef91f6773b3e455', '+634443221111'),
(10, 'Dewey', 'Plutonium', 'Dewey Curry', 'dewey@gmail.com', 'affd951c2a8753bb1da25e8e08e138c6', '+634440966666'),
(11, 'Tac', 'Bel', 'Taco \'Bout Delicious', 'taco@gmail.com', 'f869ce1c8414a264bb11e14a2c8850ed', '+634445555555');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customerID` int(11) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`customerID`, `first_name`, `last_name`, `email`, `password`, `contact_no`) VALUES
(1, 'Llean', 'Sumague', 'llean@gmail.com', '16c7712ee6356d3e4ef8766b50a29ef7', '09666665544'),
(2, 'Moreen', 'Sampang', 'moreen@gmail.com', 'a39f075b760249bccf2d26a6908eb1b5', '09994443333'),
(3, 'Justine', 'Razon', 'justine@gmail.com', '858f3b38ef738336ee49bf90e7868f98', '09444443333'),
(4, 'Lance', 'Perez', 'lance@gmail.com', '3573c6efaa587ccb25dc26fd0da4b399', '09554332222'),
(5, 'Jacob', 'Bach', 'jacob@gmail.com', '736b19f69aaca691fecd8400294cc383', '09665554444'),
(6, 'Maria', 'Perez', 'maria@gmail.com', '263bce650e68ab4e23f28263760b9fa5', '+63445556666');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu_item`
--

CREATE TABLE `tbl_menu_item` (
  `menuItemID` int(11) NOT NULL,
  `concessionerID` int(11) NOT NULL,
  `product_code` int(11) DEFAULT NULL,
  `item_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` double NOT NULL,
  `product_pic` varchar(255) NOT NULL,
  `category` enum('main dish','sides','snacks','drinks','other') NOT NULL,
  `status` enum('active','inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_menu_item`
--

INSERT INTO `tbl_menu_item` (`menuItemID`, `concessionerID`, `product_code`, `item_name`, `description`, `price`, `product_pic`, `category`, `status`) VALUES
(1, 5, 1878969, 'Pusit', 'This is a menu', 80, 'uploads/5/pusit.jpg', 'main dish', 'active'),
(2, 5, 2172488, 'Lumpiang Shanghai', 'Better than Chowking', 90, 'uploads/5/lumpiang-shanghai.jpg', 'main dish', 'active'),
(5, 4, 9445443, 'Menudo', 'pork', 90, 'uploads/5/menudo.jpg', 'main dish', 'active'),
(6, 6, 945554, 'Bicol Express', 'Masarap sa Bicol', 85, 'uploads/5/bicol-express.jpg', 'main dish', 'active'),
(7, 7, 5559555, 'Adobo', 'Only in the Philippines', 75, 'uploads/5/adobo.jpg', 'main dish', 'active'),
(8, 8, 4559555, 'Bottled Water', 'Fresh', 30, 'uploads/5/bottled-water.jpg', 'drinks', 'active'),
(9, 9, 3444444, 'Coke', 'Fresh', 40, 'uploads/5/coke.jpg', 'drinks', 'active'),
(10, 10, 3332221, 'Royal', 'Snack Kulit Time', 40, 'uploads/5/royal.jpg', 'drinks', 'active'),
(12, 10, 3444493, 'Mountain Dew', 'Unpopular Beverage', 35, 'uploads/5/mountain-dew.jpg', 'drinks', 'active'),
(13, 12, 4493433, 'Sisig', 'Nakakakiliti sa ilong', 80, 'uploads/5/sisig.jpg', 'main dish', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `orderID` int(11) NOT NULL,
  `customerID` int(11) NOT NULL,
  `order_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`orderID`, `customerID`, `order_date`) VALUES
(1, 2, '2023-12-18'),
(2, 1, '2023-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_menu`
--

CREATE TABLE `tbl_order_menu` (
  `ID` int(10) UNSIGNED NOT NULL,
  `orderID` int(11) NOT NULL,
  `MenuItemID` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price_each` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_order_menu`
--

INSERT INTO `tbl_order_menu` (`ID`, `orderID`, `MenuItemID`, `qty`, `price_each`) VALUES
(1, 1, 2, 0, 90),
(2, 1, 1, 0, 80),
(3, 1, 7, 0, 75),
(4, 1, 6, 0, 85),
(5, 2, 1, 0, 80),
(6, 2, 6, 0, 85),
(7, 2, 5, 0, 90),
(8, 2, 2, 0, 90);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `paymentID` int(11) NOT NULL,
  `customerID` int(11) NOT NULL,
  `paymentDate` date NOT NULL DEFAULT current_timestamp(),
  `paymentAmount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `tbl_concessioner`
--
ALTER TABLE `tbl_concessioner`
  ADD PRIMARY KEY (`concessionerID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `tbl_menu_item`
--
ALTER TABLE `tbl_menu_item`
  ADD PRIMARY KEY (`menuItemID`),
  ADD UNIQUE KEY `product_code` (`product_code`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `tbl_order_menu`
--
ALTER TABLE `tbl_order_menu`
  ADD PRIMARY KEY (`ID`,`orderID`,`MenuItemID`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`paymentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_concessioner`
--
ALTER TABLE `tbl_concessioner`
  MODIFY `concessionerID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customerID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_menu_item`
--
ALTER TABLE `tbl_menu_item`
  MODIFY `menuItemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_order_menu`
--
ALTER TABLE `tbl_order_menu`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `paymentID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
